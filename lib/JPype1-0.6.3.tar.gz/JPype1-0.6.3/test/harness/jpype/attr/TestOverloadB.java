package jpype.attr;

public class TestOverloadB extends TestOverloadA {
}
