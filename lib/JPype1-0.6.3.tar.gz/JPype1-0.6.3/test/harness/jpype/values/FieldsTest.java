package jpype.values;

public class FieldsTest 
{
  public static boolean booleanField;
  public static char charField;
  public static short shortField;
  public static long longField;
  public static int intField;
  public static float floatField;
  public static double doubleField;
}
