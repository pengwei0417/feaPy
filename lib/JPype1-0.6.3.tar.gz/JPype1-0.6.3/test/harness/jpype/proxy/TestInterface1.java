package jpype.proxy;

public interface TestInterface1 {

    int testMethod1();
}
