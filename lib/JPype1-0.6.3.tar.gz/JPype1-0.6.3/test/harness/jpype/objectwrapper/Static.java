package jpype.objectwrapper;

class StaticTest
{
	public static int i=1;
	public static double d=1.2345;
	public static String s="hello";
}
